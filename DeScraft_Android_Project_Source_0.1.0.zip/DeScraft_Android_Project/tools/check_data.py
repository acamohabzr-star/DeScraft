#!/usr/bin/env python3
"""Deterministic validation of the DeScraft bundled offline atlas."""
import json
from pathlib import Path
from collections import Counter
p=Path(__file__).resolve().parents[1]/'app/src/main/assets/descraftrts_data.json'
a=json.loads(p.read_text())
units=a['unitProfiles']; damage=a['damageTable']; order=a['armorOrder']
assert len(units)>400, 'Lost a large part of classic creep appendix'
assert len({u['id'] for u in units})==len(units), 'Duplicate IDs'
assert [u['category'] for u in units].count('race')>=80
assert all(len(row)==len(order) for row in damage.values())
assert all(u['attack'] in [*damage,'None'] for u in units)
assert all(u['armor'] in order+['Invulnerable'] for u in units)
assert all(u['source'] in ('modern','classic','building-reference','web-current') for u in units)
assert all(u['category'] in ('race','summon','neutral','creep') for u in units)
assert all('airborne' in u for u in units)
assert damage['Piercing'][order.index('Heavy')]==90
assert damage['Normal'][order.index('Medium')]==150
assert damage['Magic'][order.index('Heavy')]==200
assert damage['Siege'][order.index('Fortified')]==150
tracks={(t['code'],t['kind']):t for t in a['upgrades']}
for u in units:
    for kind,key in (('weapon','weaponUpgrade'),('armor','armorUpgrade')):
        if u[key]:
            assert (u[key],kind) in tracks,(u['name'],key)
            assert tracks[(u[key],kind)]['race']==u['race'],(u['name'],key)
assert 'Militia' in tracks[('H-S','weapon')]['shared']
assert 'Peasant' not in tracks[('H-S','weapon')]['shared']
assert all(u['damage'] is None for u in units if u['building'])
assert any(u['name']=='Huntress [Moon Glaives]' and u['armor']=='Heavy' for u in units)
assert any(u['name']=='Huntress [unupgraded]' and u['armor']=='Unarmored' for u in units)
assert any(u['name']=='Gargoyle [Stone Form]' and u['attack']=='None' for u in units)
assert any(u['name']=='Druid of Talon [crow]' and u['airborne'] for u in units)
assert any(u['name']=='Chimaera [Corrosive Breath]' and u['buildingOnly'] for u in units)
assert any(u['name']=='Forsaken Paladin' and u['source']=='web-current' for u in units)
# Regression check: your example, Normal+Heavy facing Piercing+Medium.
outgoing=damage['Normal'][order.index('Medium')]
incoming=damage['Piercing'][order.index('Heavy')]
assert (outgoing,incoming,outgoing-incoming)==(150,90,60)
assert round(outgoing/incoming,3)==1.667
counts=Counter(u['category'] for u in units)
print('OK: units=',len(units),'breakdown=',dict(counts),'upgrade tracks=',len(tracks))
print('Example Normal+Heavy vs Piercing+Medium: 150% dealt, 90% received; +60 pp, 1.67x')
