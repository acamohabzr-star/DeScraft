#!/usr/bin/env python3
"""Extract unit combat profiles from the two user-supplied PDF atlases.
No unknown stat is converted to zero. The newer four-race PDF takes priority;
neutral & creep rows come from the older TFT reference and are marked as such.
"""
from pathlib import Path
import re, json

ROOT = Path(__file__).resolve().parents[1]
MODERN_PDF = Path('/mnt/data/Warcraft_III_3.0.1_Four_Race_Attack_Armor_Atlas(3).pdf')
CLASSIC_PDF = Path('/mnt/data/Warcraft_III_Attack_Armor_Unit_Atlas_Audited (1).pdf')
GROUP = re.compile(r'^\s*(NORMAL|PIERCING|SIEGE|MAGIC|HERO|CHAOS|NONE)\s+ATTACK\s+(UNARMORED|LIGHT|MEDIUM|HEAVY|FORTIFIED|HERO|INVULNERABLE)\s+ARMOR\b')
ROW = re.compile(r'^\s{8,}(.+?)\s{2,}(\d+(?:\.\d+)?|[—–-])\s+(\d+(?:\.\d+)?|[—–-])\s+(\d+(?:\.\d+)?|[—–-])\s+(\d+(?:\.\d+)?|[—–-])\s+(\d+(?:\.\d+)?|[—–-])\s+(\d+(?:\.\d+)?|[—–-])\s*(.*)$')
UPG = re.compile(r'^[HONU]-[A-Z]$')

# The PDF includes only minimal hints for some race/unit associations;
# every race below is assigned explicitly to avoid guessing from placement.
HUMAN = '''Peasant Spell Breaker|Footman|Knight|Militia|Dragonhawk Rider|Rifleman|Flying Machine|Mortar Team|Siege Engine|Priest|Sorceress|Gryphon Rider|Archmage|Blood Mage|Mountain King|Paladin|Water Elemental|Phoenix'''
ORC = '''Peon|Grunt|Tauren|Dire Wolf|Shadow Wolf|Spirit Wolf|Kodo Beast|Wind Rider|Troll Berserker|Troll Headhunter|Serpent Ward|Troll Batrider|Raider|Demolisher|Shaman|Spirit Walker|Witch Doctor|Blademaster|Far Seer|Shadow Hunter|Tauren Chieftain'''
NIGHT = '''Hippogryph|Huntress|Mountain Giant|Avatar of Vengeance|Spirit of Vengeance|Druid of Claw|Druid of Talon|Treant|Dryad|Faerie Dragon|Hippogryph Rider|Chimaera|Glaive Thrower|Archer|Keeper of the Grove|Priestess of the Moon|Warden|Demon Hunter|Owl Scout|Wisp'''
UNDEAD = '''Gargoyle|Acolyte|Abomination|Carrion Beetle|Ghoul|Skeleton Warrior|Crypt Fiend|Skeletal Mage|Meat Wagon|Banshee|Necromancer|Destroyer|Frost Wyrm|Obsidian Statue|Crypt Lord|Death Knight|Dreadlord|Lich|Shade|Infernal'''
RACES={}
for race, names in [('Human',HUMAN),('Orc',ORC),('Night Elf',NIGHT),('Undead',UNDEAD)]:
 for n in names.split('|'): RACES[n.strip()]=race
# 'Peasant Spell Breaker' is two distinct names, fixed here.
RACES.pop('Peasant Spell Breaker')
RACES['Peasant']='Human'; RACES['Spell Breaker']='Human'
SUMMONS = {'Dire Wolf','Shadow Wolf','Spirit Wolf','Avatar of Vengeance','Spirit of Vengeance',
           'Treant','Skeleton Warrior','Skeletal Mage','Infernal','Phoenix','Phoenix Egg','Owl Scout',
           'Earth Spirit','Fire Spirit','Storm Spirit','Clockwerk Goblin','Dark Minion','Greater Dark Minion',
           'Lesser Dark Minion','Lava Spawn','Quilbeast','Dire Quilbeast','Raging Quilbeast',
           'Bear','Raging Bear','Spirit Bear','Spirit Hawk','Thunder Hawk','Water Elemental','Serpent Ward','Carrion Beetle','Doom Guard','Hawk'}
# Summons with an ordinary named unit (or named transformed form) are intentionally not in this list.
NEUTRAL_HEROES = {'Beastmaster','Dark Ranger','Firelord','Goblin Alchemist','Goblin Tinker',
                 'Naga Sea Witch','Pandaren Brewmaster','Pit Lord','Forsaken Paladin'}
NEUTRAL_BUYABLE = {'Goblin Shredder','Goblin Sapper','Goblin Zeppelin','Transport Ship'}
NON_COMBAT = {'Wisp','Shade','Owl Scout','Phoenix Egg','Goblin Zeppelin','Transport Ship',
              'Spirit Walker [ethereal]','Gargoyle [Stone Form]','Crypt Fiend [burrowed]'}
# Tactics/targeting: unverified targeting in the PDFs is displayed as Unknown instead of invented.
AIR_ONLY = ['Hippogryph [unmounted]','Gargoyle [air]','Druid of Talon [crow]',
            'Flying Machine [air]','Siege Engine [barrage]','Frost Wyrm [air]']
GROUND_ONLY = ['Gargoyle [ground]','Flying Machine [bombs]','Frost Wyrm [ground]',
               'Chimaera [primary]','Chimaera [Corrosive Breath]','Siege Engine [building]',
               'Mortar Team','Demolisher','Glaive Thrower','Meat Wagon','Raider','Tauren','Grunt',
               'Footman','Knight','Peasant','Militia [Peasant form]','Peon','Acolyte','Ghoul',
               'Abomination','Druid of Claw [bear]','Druid of Claw [druid]','Mountain Giant [unarmed]',
               'Mountain Giant [War Club]','Kodo Beast']
AIRBORNE_NAMES = {'Hippogryph','Gargoyle','Dragonhawk Rider','Wind Rider','Troll Batrider',
 'Faerie Dragon','Hippogryph Rider','Gryphon Rider','Chimaera','Frost Wyrm','Destroyer',
 'Flying Machine','Phoenix','Spirit Hawk','Thunder Hawk','Storm Spirit','Dragon','Drake','Dragon Whelp'}
AIRBORNE_HINTS = ('dragon','drake','harpy','wyvern','hippogryph','gargoyle','frost wyrm',
                  'faerie dragon','chimaera','wind rider','flying machine','phoenix',
                  'storm crow','spirit hawk','thunder hawk','zeppel')
BOTH_KNOWN = ['Archer','Rifleman','Gryphon Rider','Dragonhawk Rider','Wind Rider','Hippogryph Rider',
              'Crypt Fiend','Dryad','Troll Headhunter','Troll Berserker','Faerie Dragon',
              'Destroyer','Sorceress','Priest','Shaman','Necromancer','Banshee','Serpent Ward',
              'Flying Machine','Watch Tower','Guard Tower','Arcane Tower','Spirit Tower','Nerubian Tower']

def get_family(name):
 base=re.sub(r'\s*\[[^]]+\]', '', name).strip()
 base=re.sub(r'\s+(?:I|II|III|[123])$', '', base)
 if base == 'Troll Berserker': return 'Troll Headhunter'
 if base == 'Militia': return 'Peasant'
 if base == 'Phoenix Egg': return 'Phoenix'
 return base

def value(x):
 try:
  n=float(x)
  return int(n) if n.is_integer() else n
 except (ValueError, TypeError): return None

def parse_pdf(filename, pages, source):
 import subprocess
 text=subprocess.check_output(['pdftotext','-layout',str(filename),'-']).decode('utf-8', errors='replace')
 chunks=text.split('\f'); entries=[]
 for page_index in pages:
  page=chunks[page_index-1]
  attack=armor=None
  for ln in page.splitlines():
   g=GROUP.match(ln)
   if g:
    attack,armor=g.groups(); continue
   if attack is None: continue
   m=ROW.match(ln)
   if not m: continue
   name,*xs=m.groups()
   hp,dmg,defense,gold,lumber,food,rest=xs
   # PDF's fixed-position upgrade columns, absent cells stay null.
   # Some rows contain one research code only (e.g. Glaive Thrower).
   code_start=109 if source=='modern' else 110
   codes=re.findall(r'\b[HONU]-[A-Z]\b', ln[code_start:134])
   weapon=codes[0] if codes else ''
   armor_up=codes[1] if len(codes)>1 else ''
   # A lone armor track of a defenseless nonattacking form is in the A.UP column.
   if attack=='NONE' and len(codes)==1:
    armor_up=weapon; weapon=''
   attrs=[value(v) for v in re.findall(r'\d+', ln[134:150])][:3] if attack=='HERO' else []
   note=ln[169:].strip().strip('…') if len(ln)>169 else ''
   special=ln[149:169].strip() if len(ln)>149 else ''
   ent={
    'id':source+'_'+str(page_index)+'_'+str(len(entries)),
    'name':name.strip(), 'family':get_family(name.strip()),
    'attack':attack.title() if attack!='NONE' else 'None',
    'armor':armor.title() if armor!='INVULNERABLE' else 'Invulnerable',
    'hp':value(hp),'damage':value(dmg),'defense':value(defense),
    'gold':value(gold),'lumber':value(lumber),'food':value(food),
    'weaponUpgrade':weapon,'armorUpgrade':armor_up,
    'attributes':attrs,'special':special,'notes':note,
    'source':source,'sourcePage':page_index,
   }
   entries.append(ent)
 return entries

def classify(e):
 name=e['name']; family=e['family']
 is_summon=family in SUMMONS or any(family.startswith(x) for x in ['Clockwerk Goblin','Lava Spawn', 'Carrion Beetle','Serpent Ward','Water Elemental'])
 is_neutral_hero=family in NEUTRAL_HEROES
 is_neutral=e['source']=='classic' and not e.get('creep') and not is_summon and (is_neutral_hero or '[hire]' in name or name in NEUTRAL_BUYABLE or family not in RACES)
 if e.get('creep'): category='creep'; race='Creep'
 elif is_summon: category='summon'; race=RACES.get(family,'Neutral')
 elif is_neutral: category='neutral'; race='Neutral'
 else:
  category='race'; race=RACES.get(family)
  if race is None:
   category='neutral'; race='Neutral'
 e['category']=category
 e['race']=race
 if name in NON_COMBAT or e['attack']=='None' or e['armor']=='Invulnerable': e['target']='none'
 elif name in AIR_ONLY: e['target']='air'
 elif name in GROUND_ONLY: e['target']='ground'
 elif name in BOTH_KNOWN or family in BOTH_KNOWN: e['target']='both'
 else: e['target']='unknown'
 e['airborne'] = (family in AIRBORNE_NAMES or any(token in name.lower() for token in AIRBORNE_HINTS) or name == 'Druid of Talon [crow]') and not any(mark in name for mark in ('[Stone Form]', '[rooted]', '[uprooted]', 'Phoenix Egg'))
 e['buildingOnly'] = name in ('Siege Engine [building]', 'Chimaera [Corrosive Breath]')
 if e['buildingOnly']: e['target']='building'
 e['worker']=name in ['Peasant','Peon','Acolyte','Wisp','Militia [Peasant form]']
 e['noncombat']=e['attack']=='None' or e['damage'] is None
 e['building']=False
 e['spellImmune']='SPELL IMMUNE' in e['special']
 e['ethereal']='ETHEREAL' in e['special']
 e['invulnerable']=e['armor']=='Invulnerable' or 'INVULNERABLE' in e['special']
 e['researchApplicable'] = bool(e['weaponUpgrade'] or e['armorUpgrade'])
 return e

modern=parse_pdf(MODERN_PDF, range(3,8), 'modern')
classic=parse_pdf(CLASSIC_PDF,range(3,11),'classic')
creeps=parse_pdf(CLASSIC_PDF,range(11,20),'classic')
for e in creeps: e['creep']=True
# Only pull neutrals & neutral hero summons from older table, modern has all classic main-race units.
classic_extras=[]
for e in classic:
 c=classify(e)
 if c['category'] in ('neutral','summon'):
  # avoid a duplicate if the modern dataset already contains it
  if not any(m['name']==c['name'] for m in modern): classic_extras.append(c)

allunits=[classify(e) for e in modern]+classic_extras+[classify(e) for e in creeps]
# A new neutral hero was added in patch 3.0.0 and is missing from both PDF atlases.
allunits.append(classify({'id':'verified_forsaken_paladin','name':'Forsaken Paladin','family':'Forsaken Paladin',
 'attack':'Hero','armor':'Hero','hp':650,'damage':29,'defense':4,'gold':425,'lumber':135,'food':5,
 'weaponUpgrade':'','armorUpgrade':'','attributes':[22,13,17],
 'notes':'New Tavern hero in patch 3.0.0. Data from Warcraft Wiki; 3.0.1 hotfix adjusts abilities.',
 'special':'','source':'web-current','sourcePage':0}))
# Explicit building *defense* examples omitted from PDFs. Numbers are intentionally not given until
# unit-build profiles are verified against patch 3.x. Attack/armor categories below are a compact
# reference derived from Warcraft 3 building indexes (not from the user PDFs).
buildings=[
 ('Guard Tower','Human','Piercing','Heavy','both'),
 ('Cannon Tower','Human','Siege','Fortified','ground'),
 ('Arcane Tower','Human','Piercing','Heavy','both'),
 ('Watch Tower','Orc','Piercing','Heavy','both'),
 ('Spirit Tower','Undead','Piercing','Fortified','both'),
 ('Nerubian Tower','Undead','Piercing','Fortified','both'),
 ('Ancient Protector [rooted]','Night Elf','Piercing','Fortified','both'),
 ('Ancient Protector [uprooted]','Night Elf','Normal','Heavy','ground'),
 ('Ancient of War [rooted]','Night Elf','Normal','Fortified','ground'),
 ('Ancient of War [uprooted]','Night Elf','Normal','Heavy','ground'),
]
# Building armor types vary by patch, upgrade, and state. Keep conditional entries visibly flagged.
for i,(name,race,attack,armor,target) in enumerate(buildings):
 allunits.append({'id':'bld_'+str(i),'name':name,'family':get_family(name),'attack':attack,
 'armor':armor,'hp':None,'damage':None,'defense':None,'gold':None,'lumber':None,'food':None,
 'weaponUpgrade':'','armorUpgrade':'','attributes':[],'notes':'Supplemental building type from classic building references; attack/armor may change with research or form. Modern numeric stats not verified.',
 'special':'','source':'building-reference','sourcePage':0,'category':'race','race':race,'target':target,'worker':False,
 'noncombat':False,'building':True,'spellImmune':False,'ethereal':False,'invulnerable':False,'researchApplicable':False,'airborne':False,'buildingOnly':False})

UPGRADES=[
 ('H-S','weapon','Human',['Iron Forged Swords','Steel Forged Swords','Mithril Forged Swords']),
 ('H-G','weapon','Human',['Black Gunpowder','Refined Gunpowder','Imbued Gunpowder']),
 ('H-P','armor','Human',['Iron Plating','Steel Plating','Mithril Plating']),
 ('H-L','armor','Human',['Studded Leather Armor','Reinforced Leather Armor','Dragonhide Armor']),
 ('O-M','weapon','Orc',['Steel Melee Weapons','Thorium Melee Weapons','Arcanite Melee Weapons']),
 ('O-R','weapon','Orc',['Steel Ranged Weapons','Thorium Ranged Weapons','Arcanite Ranged Weapons']),
 ('O-A','armor','Orc',['Steel Unit Armor','Thorium Unit Armor','Arcanite Unit Armor']),
 ('N-M','weapon','Night Elf',['Strength of the Moon','Improved Strength of the Moon','Advanced Strength of the Moon']),
 ('N-W','weapon','Night Elf',['Strength of the Wild','Improved Strength of the Wild','Advanced Strength of the Wild']),
 ('N-M','armor','Night Elf',['Moon Armor','Improved Moon Armor','Advanced Moon Armor']),
 ('N-H','armor','Night Elf',['Reinforced Hides','Improved Reinforced Hides','Advanced Reinforced Hides']),
 ('U-U','weapon','Undead',['Unholy Strength','Improved Unholy Strength','Advanced Unholy Strength']),
 ('U-C','weapon','Undead',['Creature Attack','Improved Creature Attack','Advanced Creature Attack']),
 ('U-U','armor','Undead',['Unholy Armor','Improved Unholy Armor','Advanced Unholy Armor']),
 ('U-C','armor','Undead',['Creature Carapace','Improved Creature Carapace','Advanced Creature Carapace']),
]
upgrades=[{'id':code+'-'+kind,'code':code,'kind':kind,'race':race,'tiers':tiers,
           'shared':sorted({('Militia' if u['name'].startswith('Militia') else u['family']) for u in allunits if u['race']==race and
                     u['category'] in ('race','summon') and u.get('weaponUpgrade' if kind=='weapon' else 'armorUpgrade')==code})}
           for code,kind,race,tiers in UPGRADES]

matrix={
 'Normal':[100,100,150,100,70,100],
 'Piercing':[150,200,75,90,35,50],
 'Siege':[150,100,50,100,150,50],
 'Magic':[100,125,75,200,35,50],
 'Hero':[100,100,100,100,50,100],
 'Chaos':[100,100,100,100,100,100],
}
output={
 'version':'3.0.1 (2026-10-19)',
 'balanceReference':'2.0.4 / 2.0.3 piercing-vs-heavy update',
 'armorOrder':['Unarmored','Light','Medium','Heavy','Fortified','Hero'],
 'damageTable':matrix,
 'unitProfiles':allunits,
 'upgrades':upgrades,
 'sources':[
  {'label':'Modern four-race atlas (uploaded)', 'note':'3.0.1 four-race data, pages 3-7'},
  {'label':'Older audited atlas (uploaded)', 'note':'Classic TFT neutrals/summons/creeps, pages 3-19; not reverified for 3.0.1'},
  {'label':'Blizzard 3.0.1 patch notes','url':'https://us.forums.blizzard.com/en/warcraft3/t/warcraft-iii-reforged-forsaken-kingdom-patch-notes/38400/'},
  {'label':'Blizzard 2.0.4 balance patch','url':'https://us.forums.blizzard.com/en/warcraft3/t/warcraft-iii-reforged-patch-notes-version-204/36567'},
  {'label':'Forsaken Paladin reference','url':'https://warcraft.wiki.gg/wiki/Silas_Ashlight'},
  {'label':'Ancient Protector rooted/uprooted','url':'https://warcraft.wiki.gg/wiki/Ancient_Protector_(Warcraft_III)'},
  {'label':'Four upgrade buildings (Blizzard)','url':'https://classic.battle.net/war3/human/buildings/blacksmith.shtml'},
  {'label':'Orc War Mill','url':'https://classic.battle.net/war3/orc/buildings/warmill.shtml'},
  {'label':'Night Elf Hunter\'s Hall','url':'https://classic.battle.net/war3/nightelf/buildings/huntershall.shtml'},
  {'label':'Undead Graveyard','url':'https://classic.battle.net/war3/undead/buildings/graveyard.shtml'},
 ]
}
path=ROOT/'app/src/main/assets/descraftrts_data.json'
path.parent.mkdir(parents=True,exist_ok=True)
path.write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
print('modern:',len(modern),'classic:',len(classic),'additional classic:',len(classic_extras),'creeps:',len(creeps),'ALL:',len(allunits))
for cat in ['race','summon','neutral','creep']:
 g=[u for u in allunits if u['category']==cat]
 print(cat,len(g),'unique types:',len(set((u['attack'],u['armor']) for u in g)))
print('shared research tracks:',len(upgrades),'weapon nonempty:',sum(bool(u['weaponUpgrade']) for u in allunits))
print('Total JSON bytes',path.stat().st_size)
print('Unmapped main race profiles:',[u['name'] for u in allunits if u['source']=='modern' and u['race']=='Neutral'])
