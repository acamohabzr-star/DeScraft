package com.descraftrts.app

import android.content.Context
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ln

/** The offline atlas has two distinctly dated sources. Null numerical data means unverified. */
data class UnitProfile(
    val id: String,
    val name: String,
    val family: String,
    val race: String,
    val category: String,
    val attack: String,
    val armor: String,
    val hp: Double?,
    val damage: Double?,
    val defense: Double?,
    val gold: Double?,
    val lumber: Double?,
    val food: Double?,
    val attributes: List<Int>,
    val weaponUpgrade: String,
    val armorUpgrade: String,
    val notes: String,
    val special: String,
    val source: String,
    val target: String,
    val worker: Boolean,
    val noncombat: Boolean,
    val building: Boolean,
    val spellImmune: Boolean,
    val ethereal: Boolean,
    val invulnerable: Boolean,
    val airborne: Boolean,
    val buildingOnly: Boolean,
    val sourcePage: Int,
)

data class UpgradeTrack(
    val id: String,
    val code: String,
    val kind: String,
    val race: String,
    val tiers: List<String>,
    val shared: List<String>,
)

data class TypePair(val attack: String, val armor: String) {
    val label: String get() = "$attack + $armor"
}

data class Matchup(
    val opponent: TypePair,
    val outgoing: Int,
    val incoming: Int,
    val roster: List<UnitProfile>,
) {
    val difference: Int get() = outgoing - incoming
    val ratio: Double get() = outgoing.toDouble() / incoming.toDouble()
    val logRatio: Double get() = ln(ratio) / ln(2.0)
    fun score(ratioMode: Boolean): Double = if (ratioMode) logRatio else difference.toDouble()
    val immunity: Boolean get() = roster.any { it.spellImmune }
}

class Atlas(
    val units: List<UnitProfile>,
    val tracks: List<UpgradeTrack>,
    val armorOrder: List<String>,
    val matrix: Map<String, List<Int>>,
    val version: String,
) {
    fun multiplier(attack: String, armor: String): Int? {
        val column = armorOrder.indexOf(armor)
        if (column < 0) return null
        return matrix[attack]?.getOrNull(column)
    }
    fun matchup(self: TypePair, enemy: TypePair, units: List<UnitProfile>): Matchup? {
        val outgoing = multiplier(self.attack, enemy.armor) ?: return null
        val incoming = multiplier(enemy.attack, self.armor) ?: return null
        return Matchup(enemy, outgoing, incoming, units)
    }
    fun track(code: String, kind: String): UpgradeTrack? = tracks.firstOrNull {
        it.code == code && it.kind == kind
    }
}

object AtlasRepository {
    fun load(context: Context): Atlas {
        val raw = context.assets.open("descraftrts_data.json").bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        val unitArray = root.getJSONArray("unitProfiles")
        val list = buildList {
            for (i in 0 until unitArray.length()) {
                val obj = unitArray.getJSONObject(i)
                val attributes = obj.optJSONArray("attributes")
                add(UnitProfile(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    family = obj.getString("family"),
                    race = obj.getString("race"),
                    category = obj.getString("category"),
                    attack = obj.getString("attack"),
                    armor = obj.getString("armor"),
                    hp = obj.optionalNumber("hp"),
                    damage = obj.optionalNumber("damage"),
                    defense = obj.optionalNumber("defense"),
                    gold = obj.optionalNumber("gold"),
                    lumber = obj.optionalNumber("lumber"),
                    food = obj.optionalNumber("food"),
                    attributes = if (attributes == null) emptyList() else (0 until attributes.length()).map { attributes.getInt(it) },
                    weaponUpgrade = obj.optString("weaponUpgrade", ""),
                    armorUpgrade = obj.optString("armorUpgrade", ""),
                    notes = obj.optString("notes", ""),
                    special = obj.optString("special", ""),
                    source = obj.optString("source", ""),
                    target = obj.optString("target", "unknown"),
                    worker = obj.optBoolean("worker"),
                    noncombat = obj.optBoolean("noncombat"),
                    building = obj.optBoolean("building"),
                    spellImmune = obj.optBoolean("spellImmune"),
                    ethereal = obj.optBoolean("ethereal"),
                    invulnerable = obj.optBoolean("invulnerable"),
                    airborne = obj.optBoolean("airborne"),
                    buildingOnly = obj.optBoolean("buildingOnly"),
                    sourcePage = obj.optInt("sourcePage", 0)
                ))
            }
        }
        val upgradeArray = root.getJSONArray("upgrades")
        val tracks = buildList {
            for (i in 0 until upgradeArray.length()) {
                val obj = upgradeArray.getJSONObject(i)
                fun arr(key: String) = obj.getJSONArray(key).let { a -> (0 until a.length()).map { a.getString(it) } }
                add(UpgradeTrack(obj.getString("id"), obj.getString("code"), obj.getString("kind"),
                    obj.getString("race"), arr("tiers"), arr("shared")))
            }
        }
        val columns = root.getJSONArray("armorOrder").let { a -> (0 until a.length()).map { a.getString(it) } }
        val data = root.getJSONObject("damageTable")
        val matrix = buildMap {
            for (key in listOf("Normal", "Piercing", "Siege", "Magic", "Hero", "Chaos")) {
                val row = data.getJSONArray(key)
                put(key, (0 until row.length()).map { row.getInt(it) })
            }
        }
        return Atlas(list, tracks, columns, matrix, root.getString("version"))
    }
    private fun JSONObject.optionalNumber(key: String): Double? =
        if (!has(key) || isNull(key)) null else optDouble(key).takeIf { !it.isNaN() }
}

fun List<UnitProfile>.withinLevel(level: Int, workers: Boolean, noncombat: Boolean, buildings: Boolean): List<UnitProfile> =
    filter { u ->
        val within = when (u.category) {
            "race" -> true
            "summon" -> level >= 1
            "neutral" -> level >= 2
            "creep" -> level >= 3
            else -> false
        }
        within && (workers || !u.worker) && (noncombat || !u.noncombat) && (buildings || !u.building)
    }

fun List<UnitProfile>.combatOnly() = filter { it.attack != "None" && it.armor != "Invulnerable" && !it.noncombat }

fun List<UnitProfile>.typePairs(): List<TypePair> = combatOnly()
    .map { TypePair(it.attack, it.armor) }
    .distinct()
    .sortedWith(compareBy({ listOf("Normal","Piercing","Siege","Magic","Hero","Chaos").indexOf(it.attack) },
        { listOf("Unarmored","Light","Medium","Heavy","Fortified","Hero").indexOf(it.armor) }))

/** Filters attack eligibility against known ground/air classifications. */
fun canHit(attacker: UnitProfile, victim: UnitProfile): Boolean = when(attacker.target) {
    "building" -> victim.building
    "both" -> true
    "air" -> victim.airborne
    "ground" -> !victim.airborne
    "none" -> false
    else -> false // Unknown targeting is never claimed to be verified.
}

fun eligibleExchange(from: List<UnitProfile>, to: List<UnitProfile>): Boolean =
    from.any { own -> to.any { enemy -> canHit(own, enemy) && canHit(enemy, own) } }

fun numberLabel(number: Double?): String = when {
    number == null -> "—"
    number % 1.0 == 0.0 -> number.toInt().toString()
    else -> "%.1f".format(java.util.Locale.US, number)
}
