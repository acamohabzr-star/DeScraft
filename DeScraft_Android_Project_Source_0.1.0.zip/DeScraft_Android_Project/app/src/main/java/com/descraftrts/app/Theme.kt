package com.descraftrts.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B1220)
val Panel = Color(0xFF151F30)
val Panel2 = Color(0xFF1B2940)
val Blue = Color(0xFF72A9E8)
val DeepBlue = Color(0xFF154C9C)
val Ember = Color(0xFFC76C77)
val Silver = Color(0xFFD2D8E4)
val Muted = Color(0xFF8B9CAF)
val Hairline = Color(0xFF34445A)
val Gold = Color(0xFFB9A987)

fun factionColor(faction: String): Color = when(faction) {
    "Human" -> Color(0xFF6B9DE8)
    "Orc" -> Color(0xFFD58F57)
    "Night Elf" -> Color(0xFF69B6A0)
    "Undead" -> Color(0xFF9A85BF)
    "Neutral" -> Color(0xFFB7B4A4)
    else -> Color(0xFF7E8999)
}

private val DeScraftColors = darkColorScheme(
    primary = Blue, secondary = Gold, tertiary = Ember,
    background = Navy, surface = Panel, surfaceVariant = Panel2,
    onBackground = Silver, onSurface = Silver, onSurfaceVariant = Muted,
    outline = Hairline
)

@Composable
fun DeScraftTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DeScraftColors, content = content)
}
