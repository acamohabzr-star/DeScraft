package com.descraftrts.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DeScraftTheme { MainScreen() } }
    }
}

private val levelNames = listOf("4 Races", "+ Summons", "+ Neutrals", "+ Creeps")
private val attacks = listOf("Normal", "Piercing", "Siege", "Magic", "Hero", "Chaos")
private val armors = listOf("Unarmored", "Light", "Medium", "Heavy", "Fortified", "Hero")

@Composable
private fun MainScreen() {
    val context = LocalContext.current
    val result = remember(context) { runCatching { AtlasRepository.load(context) } }
    val atlas = result.getOrNull()
    if (atlas == null) {
        Box(Modifier.fillMaxSize().background(Navy).padding(28.dp), contentAlignment = Alignment.Center) {
            Text("Could not read offline atlas: ${result.exceptionOrNull()?.message ?: "Unknown error"}", color = Silver)
        }
        return
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var level by rememberSaveable { mutableIntStateOf(0) }
    var workers by rememberSaveable { mutableStateOf(true) }
    var noncombat by rememberSaveable { mutableStateOf(true) }
    var buildings by rememberSaveable { mutableStateOf(false) }
    var ratioMode by rememberSaveable { mutableStateOf(false) }
    var autoScale by rememberSaveable { mutableStateOf(true) }
    var eligibility by rememberSaveable { mutableStateOf(false) }
    var selectedAttack by rememberSaveable { mutableStateOf("Normal") }
    var selectedArmor by rememberSaveable { mutableStateOf("Heavy") }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var filtersOpen by rememberSaveable { mutableStateOf(false) }
    var highlighted by remember { mutableStateOf<String?>(null) }
    val chosen = TypePair(selectedAttack, selectedArmor)

    val visible = remember(atlas, level, workers, noncombat, buildings) {
        atlas.units.withinLevel(level, workers, noncombat, buildings)
    }
    val pairs = remember(visible) { visible.typePairs() }
    val grouped = remember(visible) { visible.groupBy { TypePair(it.attack, it.armor) } }
    val allMatchups = remember(atlas, visible, chosen, eligibility) {
        pairs.mapNotNull { enemy ->
            val roster = grouped[enemy].orEmpty()
            val ours = grouped[chosen].orEmpty()
            if (eligibility && !eligibleExchange(ours, roster)) null else atlas.matchup(chosen, enemy, roster)
        }.sortedByDescending { it.difference }
    }
    val selectedRoster = grouped[chosen].orEmpty()

    Column(Modifier.fillMaxSize().background(Navy)) {
        Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("DeScraft", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Silver)
                Spacer(Modifier.weight(1f))
                Text("◈  Offline atlas", color = Blue, fontSize = 11.sp)
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { searchOpen = true }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)) {
                    Text("⌕ Search", fontSize = 12.sp)
                }
            }
            Text("WARCRAFT III  •  TYPE ADVANTAGE  •  PATCH 3.0.1", color = Muted, fontSize = 10.sp)
        }
        HorizontalDivider(color = Hairline)
        LevelSelector(level = level, onLevel = { level = it })
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { filtersOpen = !filtersOpen }) { Text(if (filtersOpen) "▾ Roster filters" else "▸ Roster filters", fontSize = 12.sp) }
            Spacer(Modifier.weight(1f))
            Text("${visible.size} profiles · ${pairs.size} combat types", color = Muted, fontSize = 11.sp)
        }
        if (filtersOpen) {
            Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 16.dp, vertical = 5.dp)) {
                SettingSwitch("Workers", workers, onChange = { workers = it })
                SettingSwitch("Noncombat units (roster only)", noncombat, onChange = { noncombat = it })
                SettingSwitch("Defensive buildings (supplemental reference)", buildings, onChange = { buildings = it })
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TabChoice("ADVANTAGE GRAPH", tab == 0, Modifier.weight(1f)) { tab = 0 }
            TabChoice("UNIT ROSTER", tab == 1, Modifier.weight(1f)) { tab = 1 }
        }
        if (tab == 0) {
            GraphScreen(
                atlas = atlas, selected = chosen, pairs = pairs, matchups = allMatchups,
                selectedAttack = selectedAttack, selectedArmor = selectedArmor,
                onAttack = { attack ->
                    selectedAttack = attack
                    val valid = pairs.firstOrNull { it.attack == attack && it.armor == selectedArmor }
                    if (valid == null) selectedArmor = pairs.firstOrNull { it.attack == attack }?.armor ?: selectedArmor
                },
                onArmor = { selectedArmor = it }, ratioMode = ratioMode, onRatioMode = { ratioMode = it },
                autoScale = autoScale, onAutoScale = { autoScale = it }, eligibility = eligibility,
                onEligibility = { eligibility = it }, highlighted = highlighted,
                onSelect = { matchup ->
                    highlighted = matchup.opponent.label
                    // The roster tab displays the tapped opponent, without changing the viewpoint.
                    tab = 1
                },
                onSelectedRoster = { highlighted = chosen.label; tab = 1 }
            )
        } else {
            val inspected = remember(highlighted, chosen, visible) {
                visible.map { TypePair(it.attack, it.armor) }.distinct().firstOrNull { it.label == highlighted } ?: chosen
            }
            val inspection = atlas.matchup(chosen, inspected, grouped[inspected].orEmpty())
            RosterScreen(
                atlas = atlas, selected = chosen, inspected = inspected, matchup = inspection,
                roster = visible.filter { it.attack == inspected.attack && it.armor == inspected.armor },
                allVisible = visible,
                onBackGraph = { tab = 0 },
                onInspectSelf = { highlighted = chosen.label },
                onCompareFromHere = {
                    selectedAttack = inspected.attack
                    selectedArmor = inspected.armor
                    highlighted = null
                    tab = 0
                }
            )
        }
    }

    if (searchOpen) {
        UnitSearchDialog(visible = visible, onDismiss = { searchOpen = false }, onPick = { picked ->
            val pick = TypePair(picked.attack, picked.armor)
            if (pick in pairs) {
                selectedAttack = picked.attack
                selectedArmor = picked.armor
                tab = 0
            } else {
                tab = 1 // Noncombat, invulnerable or special forms belong in the roster, not on the matchup graph.
            }
            highlighted = pick.label
            searchOpen = false
        })
    }
}

@Composable
private fun LevelSelector(level: Int, onLevel: (Int) -> Unit) {
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(levelNames.size) { i ->
            FilterChip(selected = level == i, onClick = { onLevel(i) }, label = { Text(levelNames[i], fontSize = 12.sp) })
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(43.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 12.sp, color = Silver)
        Switch(checked = checked, onCheckedChange = onChange, modifier = Modifier.height(35.dp))
    }
}

@Composable
private fun TabChoice(label: String, checked: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(10.dp),
        color = if (checked) Panel2 else Panel,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (checked) Blue else Hairline)) {
        Text(label, modifier = Modifier.padding(vertical = 10.dp), fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal,
            color = if (checked) Silver else Muted, textAlign = TextAlign.Center, fontSize = 11.sp)
    }
}

@Composable
private fun Picker(label: String, options: List<String>, current: String, onPicked: (String) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp)) {
            Column(Modifier.weight(1f)) {
                Text(label, color = Muted, fontSize = 9.sp)
                Text(current, color = Silver, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            }
            Text("⌄", color = Blue)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { item ->
                DropdownMenuItem(text = { Text(item) }, onClick = {
                    onPicked(item); expanded = false
                })
            }
        }
    }
}

@Composable
private fun GraphScreen(
    atlas: Atlas,
    selected: TypePair,
    pairs: List<TypePair>,
    matchups: List<Matchup>,
    selectedAttack: String,
    selectedArmor: String,
    onAttack: (String) -> Unit,
    onArmor: (String) -> Unit,
    ratioMode: Boolean,
    onRatioMode: (Boolean) -> Unit,
    autoScale: Boolean,
    onAutoScale: (Boolean) -> Unit,
    eligibility: Boolean,
    onEligibility: (Boolean) -> Unit,
    highlighted: String?,
    onSelect: (Matchup) -> Unit,
    onSelectedRoster: () -> Unit,
) {
    val attacksAvailable = pairs.map { it.attack }.distinct()
    val armorAvailable = pairs.filter { it.attack == selectedAttack }.map { it.armor }.distinct()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Text("YOUR SELECTED TYPE", modifier = Modifier.padding(top = 8.dp, bottom = 5.dp), fontSize = 11.sp,
            color = Muted, fontWeight = FontWeight.Medium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Picker("DAMAGE TYPE", attacksAvailable, selectedAttack, onAttack, Modifier.weight(1f))
            Picker("ARMOR TYPE", armorAvailable, selectedArmor, onArmor, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("${selected.label}", color = Silver, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f))
            TextButton(onClick = onSelectedRoster) { Text("See own units ›", fontSize = 12.sp) }
        }
        if (pairs.none { it == selected }) {
            Text("This pair is not present with the active roster filters.", color = Ember, fontSize = 12.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            SmallToggle("Difference", !ratioMode) { onRatioMode(false) }
            SmallToggle("Ratio", ratioMode) { onRatioMode(true) }
            Spacer(Modifier.weight(1f))
            SmallToggle("Fixed", !autoScale) { onAutoScale(false) }
            SmallToggle("Auto", autoScale) { onAutoScale(true) }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Target eligibility (mutual attacks)", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Switch(checked = eligibility, onCheckedChange = onEligibility)
        }
        Text(
            if (ratioMode) "Ratio: (your outgoing damage %) ÷ (enemy outgoing damage %). The graph uses a symmetrical log scale."
            else "Difference: your outgoing damage % minus their outgoing damage %. Zero means equal type multipliers.",
            fontSize = 10.sp, color = Muted, lineHeight = 14.sp
        )
        Spacer(Modifier.height(7.dp))
        GraphPanel(matchups, selected, ratioMode, autoScale, highlighted, onSelect)
        Spacer(Modifier.height(8.dp))
        Text("HIGHER = your selected type has a better exchange of type multipliers. This is not a DPS, armor-value or battle-outcome calculator.",
            color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
        if (eligibility) {
            Text("Eligibility uses known attack and flying/ground status. Unverified targeting is excluded, rather than guessed.",
                color = Gold, fontSize = 10.sp, lineHeight = 15.sp)
        }
        Text("Source: 3.0.1 four-race atlas; neutral and creep profiles retained from the older classic atlas.",
            color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp, bottom = 16.dp))
    }
}

@Composable
private fun SmallToggle(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(8.dp),
        color = if (active) Panel2 else Panel, border = androidx.compose.foundation.BorderStroke(1.dp, if (active) Blue else Hairline)) {
        Text(label, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            color = if (active) Silver else Muted, fontSize = 11.sp)
    }
}

private data class ChipPosition(val matchup: Matchup, val lane: Int, val y: Float)

/** Retains exact matchup Y coordinates; equal scores are distributed into horizontal lanes. */
private fun arrange(matchups: List<Matchup>, lanes: Int, fullHeight: Float, extent: Double, ratio: Boolean): List<ChipPosition> {
    val ends = MutableList(lanes) { -1000f }
    val positions = mutableListOf<ChipPosition>()
    matchups.sortedByDescending { it.score(ratio) }.forEach { m ->
        val norm = (m.score(ratio) / extent).coerceIn(-1.0, 1.0)
        val y = ((1 - norm) * 0.5 * (fullHeight - 52f) + 26f).toFloat()
        val lane = ends.indices.filter { ends[it] < y - 33f }.minByOrNull { ends[it] }
            ?: ends.indices.minByOrNull { ends[it] } ?: 0
        ends[lane] = y
        positions += ChipPosition(m, lane, y)
    }
    return positions
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GraphPanel(
    matchups: List<Matchup>, selected: TypePair, ratioMode: Boolean, autoScale: Boolean,
    highlighted: String?, onSelect: (Matchup) -> Unit,
) {
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var tooltip by remember { mutableStateOf<Matchup?>(null) }
    val extent = if (autoScale) max(1.0, matchups.maxOfOrNull { abs(it.score(ratioMode)) } ?: 1.0)
                 else if (ratioMode) 3.0 else 165.0
    Surface(shape = RoundedCornerShape(14.dp), color = Panel,
        border = androidx.compose.foundation.BorderStroke(1.dp, Hairline)) {
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("TYPE ADVANTAGE MAP", color = Silver, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("${matchups.size} profiles", color = Muted, fontSize = 10.sp)
                Spacer(Modifier.width(9.dp))
                TextButton(onClick = { zoom = 1f; pan = Offset.Zero }, contentPadding = PaddingValues(0.dp)) {
                    Text("Reset view", fontSize = 11.sp)
                }
            }
            BoxWithConstraints(Modifier.fillMaxWidth().height(700.dp).clip(RoundedCornerShape(7.dp))
                .background(Brush.verticalGradient(listOf(
                    Color(0xFF134A88), Color(0xFF245A87), Color(0xFF253F58),
                    Color(0xFF2B3545), Color(0xFF58404B), Color(0xFF85424C), Color(0xFF932F42)
                )))) {
                val lanes = if (maxWidth >= 440.dp) 4 else 3
                val chipWidth = (maxWidth - 14.dp) / lanes
                val arranged = remember(matchups, lanes, extent, ratioMode) { arrange(matchups, lanes, 700f, extent, ratioMode) }
                Box(Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, drag, change, _ ->
                            zoom = (zoom * change).coerceIn(1f, 3.5f)
                            pan += drag
                        }
                    }
                    .graphicsLayer(scaleX = zoom, scaleY = zoom, translationX = pan.x, translationY = pan.y)) {
                    Canvas(Modifier.fillMaxSize()) {
                        val mid = size.height / 2f
                        drawLine(Color.White.copy(alpha = 0.12f), Offset(0f, mid), Offset(size.width, mid), strokeWidth = 2f)
                        drawLine(Color.White.copy(alpha = 0.09f), Offset(0f, size.height / 4f), Offset(size.width, size.height / 4f))
                        drawLine(Color.White.copy(alpha = 0.09f), Offset(0f, size.height * 3 / 4f), Offset(size.width, size.height * 3 / 4f))
                    }
                    Text("STRONGER", modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
                        color = Color.White.copy(alpha = 0.58f), fontSize = 10.sp)
                    Text("EVEN", modifier = Modifier.align(Alignment.CenterStart).padding(start = 10.dp),
                        color = Color.White.copy(alpha = 0.55f), fontSize = 10.sp)
                    Text("WEAKER", modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
                        color = Color.White.copy(alpha = 0.58f), fontSize = 10.sp)
                    arranged.forEach { p ->
                        val left = (p.lane * chipWidth.value + 6f).dp
                        val top = (p.y - 18f).dp
                        Surface(
                            modifier = Modifier.offset(x = left, y = top).width(chipWidth - 4.dp).heightIn(min = 31.dp, max = 47.dp)
                                .combinedClickable(onClick = { onSelect(p.matchup) }, onLongClick = { tooltip = p.matchup }),
                            color = if (p.matchup.opponent.label == highlighted) Color(0xFF304F6C) else Panel.copy(alpha = 0.88f),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp,
                                if (p.matchup.opponent.label == highlighted) Silver else Color.White.copy(alpha = 0.19f))
                        ) {
                            Column(Modifier.padding(horizontal = 5.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(p.matchup.opponent.label, color = Silver, fontSize = 9.sp,
                                    lineHeight = 11.sp, textAlign = TextAlign.Center, maxLines = 2)
                                Text(
                                    if (ratioMode) "${"%.2f".format(java.util.Locale.US, p.matchup.ratio)}×"
                                    else "${if (p.matchup.difference > 0) "+" else ""}${p.matchup.difference} pp",
                                    color = if (p.matchup.difference >= 0) Blue else Ember,
                                    fontWeight = FontWeight.Bold, fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
            Text("Tap a type to open its units · Long-press for damage multipliers · Pinch to zoom · Drag to pan",
                color = Muted, fontSize = 10.sp, modifier = Modifier.padding(10.dp))
        }
    }
    tooltip?.let { m ->
        AlertDialog(onDismissRequest = { tooltip = null },
            title = { Text(m.opponent.label, color = Silver) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Selected type: ${selected.label}")
                    Text("Damage dealt: ${m.outgoing}%")
                    Text("Damage received: ${m.incoming}%")
                    Text("Difference: ${if (m.difference > 0) "+" else ""}${m.difference} percentage points")
                    Text("Ratio: ${"%.2f".format(java.util.Locale.US, m.ratio)}×")
                    if (m.immunity) Text("Contains spell-immune units. Does not change attack-type multipliers.", color = Gold)
                    Text("${m.roster.size} units/forms in current roster scope", color = Muted)
                }
            }, confirmButton = { TextButton(onClick = { tooltip = null; onSelect(m) }) { Text("Open units") } },
            dismissButton = { TextButton(onClick = { tooltip = null }) { Text("Close") } }
        )
    }
}

@Composable
private fun RosterScreen(
    atlas: Atlas,
    selected: TypePair,
    inspected: TypePair,
    matchup: Matchup?,
    roster: List<UnitProfile>,
    allVisible: List<UnitProfile>,
    onBackGraph: () -> Unit,
    onInspectSelf: () -> Unit,
    onCompareFromHere: () -> Unit,
) {
    var text by rememberSaveable(inspected.label) { mutableStateOf("") }
    val filtered = remember(roster, text) { roster.filter { it.name.contains(text, ignoreCase = true) } }
    val families = remember(filtered) { filtered.groupBy { it.family }.toSortedMap() }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().background(Panel).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(inspected.label, color = Silver, fontWeight = FontWeight.Bold, fontSize = 19.sp,
                    modifier = Modifier.weight(1f))
                TextButton(onClick = onBackGraph) { Text("‹ Graph") }
            }
            if (matchup != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MiniStat("YOU DEAL", "${matchup.outgoing}%", Blue, Modifier.weight(1f))
                    MiniStat("YOU RECEIVE", "${matchup.incoming}%", Ember, Modifier.weight(1f))
                    MiniStat("NET", "${if (matchup.difference>0) "+" else ""}${matchup.difference} pp", Silver, Modifier.weight(1f))
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${filtered.size} profiles · ${families.size} unit families", color = Muted, fontSize = 11.sp,
                    modifier = Modifier.weight(1f))
                TextButton(onClick = onInspectSelf) { Text("My type", fontSize = 12.sp) }
                TextButton(onClick = onCompareFromHere) { Text("⇄ Compare from here", fontSize = 12.sp) }
            }
            OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true,
                label = { Text("Filter units in this type") }, modifier = Modifier.fillMaxWidth())
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            if (families.isEmpty()) {
                item {
                    Text("No units match these filters. Try another roster level, switch on workers/noncombat/buildings, or clear the search.",
                        color = Muted, modifier = Modifier.padding(20.dp))
                }
            }
            families.forEach { (family, members) ->
                item(key = family) {
                    UnitFamilyCard(family = family, members = members, allVisible = allVisible, atlas = atlas)
                }
            }
            item {
                Text("Main-race statistics: patch 3.0.1 atlas. Neutral and creep records: older TFT reference; may differ from current patch. " +
                    "Em dashes mean unknown, not zero. Base per-hit damage is not DPS.",
                    color = Muted, fontSize = 10.sp, modifier = Modifier.padding(8.dp))
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.background(Panel2, RoundedCornerShape(8.dp)).padding(9.dp)) {
        Text(label, color = Muted, fontSize = 9.sp)
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
private fun UnitFamilyCard(family: String, members: List<UnitProfile>, allVisible: List<UnitProfile>, atlas: Atlas) {
    var open by rememberSaveable(family) { mutableStateOf(false) }
    val first = members.first()
    Surface(shape = RoundedCornerShape(12.dp), color = Panel,
        border = androidx.compose.foundation.BorderStroke(1.dp, Hairline)) {
        Column {
            Row(Modifier.fillMaxWidth().clickable { open = !open }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(RoundedCornerShape(3.dp)).background(factionColor(first.race)))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(family, color = Silver, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Text("${first.race} · ${members.size} matching form(s)" +
                        if (first.source == "classic") " · Classic reference" else "", color = Muted, fontSize = 11.sp)
                }
                Text(if (open) "⌃" else "⌄", color = Blue)
            }
            if (open) {
                HorizontalDivider(color = Hairline)
                members.forEach { unit ->
                    UnitDetail(unit, atlas)
                    HorizontalDivider(color = Hairline.copy(alpha = 0.5f))
                }
                val others = allVisible.filter { it.family == family && it.id !in members.map { m -> m.id } }
                if (others.isNotEmpty()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("OTHER FORMS / ATTACK MODES", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        others.forEach { alt ->
                            Text("${alt.name}: ${alt.attack} + ${alt.armor}", color = Muted, fontSize = 11.sp,
                                modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UnitDetail(u: UnitProfile, atlas: Atlas) {
    Column(Modifier.padding(horizontal = 12.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(u.name, fontWeight = FontWeight.Bold, color = Silver, fontSize = 14.sp)
        Text("${u.attack} damage · ${u.armor} armor · Targets: ${u.target}" +
            if (u.airborne) " · Flying" else "", color = Blue, fontSize = 11.sp)
        val stats = "♥ ${numberLabel(u.hp)}   ⚔ ${numberLabel(u.damage)}   ⛨ ${numberLabel(u.defense)}   " +
            "● ${numberLabel(u.gold)}   ♣ ${numberLabel(u.lumber)}   ◆ ${numberLabel(u.food)}"
        Text(stats, color = Silver, fontSize = 11.sp, lineHeight = 17.sp)
        if (u.attributes.isNotEmpty()) {
            Text("L1 attributes · STR ${u.attributes.getOrNull(0) ?: "—"}  AGI ${u.attributes.getOrNull(1) ?: "—"}  INT ${u.attributes.getOrNull(2) ?: "—"}",
                color = Muted, fontSize = 11.sp)
        }
        val features = listOfNotNull(if (u.spellImmune) "SPELL IMMUNE" else null,
            if (u.ethereal) "ETHEREAL" else null, if (u.invulnerable) "INVULNERABLE" else null,
            if (u.building) "BUILDING (SUPPLEMENTAL)" else null, if (u.category == "summon") "SUMMON" else null)
        if (features.isNotEmpty()) Text(features.joinToString("  ·  "), color = Gold, fontSize = 10.sp)
        if (u.race in listOf("Human", "Orc", "Night Elf", "Undead") && !u.building) {
            UpgradeTrackCard("WEAPON RESEARCH", atlas.track(u.weaponUpgrade, "weapon"))
            UpgradeTrackCard("ARMOR RESEARCH", atlas.track(u.armorUpgrade, "armor"))
        }
        if (u.notes.isNotBlank()) Text(u.notes, color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
        Text("Source: ${sourceName(u.source)}" + if (u.sourcePage > 0) " · PDF p.${u.sourcePage}" else "",
            color = Muted.copy(alpha = 0.75f), fontSize = 10.sp)
    }
}

private fun sourceName(s: String) = when (s) {
    "modern" -> "3.0.1 four-race atlas"
    "classic" -> "classic TFT atlas (not fully reverified)"
    "web-current" -> "current hero reference"
    "building-reference" -> "supplemental building reference"
    else -> "unverified source"
}

@Composable
private fun UpgradeTrackCard(label: String, track: UpgradeTrack?) {
    var sharedOpen by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(8.dp)).padding(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            Text(track?.code ?: "NO RESEARCH TRACK", color = Muted, fontSize = 10.sp)
        }
        if (track != null) {
            track.tiers.forEachIndexed { i, tier ->
                Text("${i + 1}. $tier", color = Silver, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
            }
            TextButton(onClick = { sharedOpen = !sharedOpen }, contentPadding = PaddingValues(0.dp)) {
                Text(if (sharedOpen) "Hide units sharing research ▴" else "Show units sharing research ▾", fontSize = 11.sp)
            }
            if (sharedOpen) {
                Text(track.shared.joinToString(" · ").ifBlank { "No shared units verified" },
                    color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                Text("Same race and research track. Alternate forms can have different eligibility.",
                    color = Muted, fontSize = 10.sp)
            }
        } else {
            Text("No applicable research track recorded for this form in the source atlas.",
                color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun UnitSearchDialog(visible: List<UnitProfile>, onDismiss: () -> Unit, onPick: (UnitProfile) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val found = remember(visible, query) {
        visible.filter { it.name.contains(query.trim(), ignoreCase = true) }.take(70)
    }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text("Find a unit") },
        text = {
            Column {
                OutlinedTextField(value = query, onValueChange = { query = it },
                    singleLine = true, label = { Text("Name / form") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 350.dp)) {
                    items(found, key = { it.id }) { u ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(u) }.padding(vertical = 10.dp)) {
                            Text(u.name, color = Silver, fontSize = 13.sp)
                            Text("${u.race} · ${u.attack} + ${u.armor}", color = Muted, fontSize = 11.sp)
                        }
                        HorizontalDivider(color = Hairline)
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
