# Data is loaded from a bundled JSON atlas. No reflection-heavy models to keep.
