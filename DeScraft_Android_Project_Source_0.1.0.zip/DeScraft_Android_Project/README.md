# DeScraft · Warcraft III Type Advantage Analyzer

**Version:** source preview 0.1.0 · **Target:** Android 8.0+ · **Offline:** yes

This is a native Android project written in **Kotlin + Jetpack Compose**, built around the 15 choices approved for DeScraft. The launcher artwork is the approved **icon #6**: navy blue, silver compass and blue/red graph.

## What works in the source implementation

- Choose any existing **damage type + armor type** in the selected roster scope.
- View the blue → slate-neutral → red vertical advantage map. Each floating label is another existing combined type. Better outgoing-vs-incoming multipliers place the opponent higher; worse exchanges place it lower.
- Switch between **percentage-point difference** and **damage multiplier ratio**. The ratio uses a symmetric log2 coordinate so reciprocal matchups occupy opposite distances from the midpoint.
- Switch between **fixed** (same across selections) and **automatic** vertical scaling.
- The scope selector is cumulative: **four main races**, **+ summons**, **+ neutral mercenaries/Tavern heroes**, **+ wild creeps**.
- Extra roster filters for workers, noncombat units, and defensive buildings. Noncombat/invulnerable profiles stay out of the score graph but can be found in search and viewed in the roster.
- An optional **mutual target-eligibility** filter uses known ground, airborne, and buildings-only restrictions; units with unknown targeting are not treated as verified matches.
- Tap a graph item to open a separate **unit roster tab**, preserving the selected viewpoint/graph. Long-press a graph item to see outgoing/incoming percentages, ratio, net advantage and spell-immunity indications.
- Pinch/zoom/pan the graph; reset view.
- Search units and combat forms, and jump to their type. Inspect your own type, or swap perspective to compare from a type in the roster.
- Sort units into family cards, expand per-form stats (HP, average basic hit, numerical armor, gold, lumber, food and hero level-1 STR/AGI/INT), and see alternate combat forms.
- Expand **exactly named weapon and armor upgrade tracks**, all research tiers, and other units sharing the track. No upgrade association is invented for units without an upgrade code in the uploaded references.

## Data sources and caveats

The **modern four-race source** is the user-supplied `Warcraft_III_3.0.1_Four_Race_Attack_Armor_Atlas(3).pdf` (pages 3–7). The older `Warcraft_III_Attack_Armor_Unit_Atlas_Audited (1).pdf` supplies older Tavern heroes, mercenaries and wild creep profiles, as it explicitly does *not* represent live 3.x balance. Current balance multipliers are from the first PDF, including **Piercing → Heavy = 90%** in patch 2.0.4.

The dataset also includes **supplemental, flagged** limited entries for selected defensive structures, since the attached PDFs do not provide a modern building stat atlas. Their missing HP, damage, defense, costs and upgrades remain null; do not mistake these for verified stats. The newest Tavern hero **Forsaken Paladin** is separately tagged as web-current because neither PDF enumerated him.

**Important interpretation:** The plotted exchange compares damage *type* multipliers only. It does not incorporate numerical armor, HP, actual DPS, movement, range, attack speed, abilities, splash, ethereal/spell immunity or action economy. Spell immunity is indicated on rosters, not folded into the type-only score.

### Why no compiled APK is included in this package

This execution environment has the JDK and Kotlin CLI, but no Android SDK, `aapt2`, D8/R8, Gradle installation or cached Android/Jetpack dependency artifacts. We cannot claim an APK without building and verifying one. The source zip is **not** an APK and has not been emulator-tested.

## Build and install with Android Studio

1. Install **Android Studio** with SDK Platform **35** (Android 15) and Android SDK Build Tools. Use JDK 17 or 21.
2. Open the **DeScraft_Android_Project** folder itself, not the `app` subfolder.
3. Allow Android Studio to sync Gradle plugins and Jetpack Compose dependencies. Internet is needed **at build time only**.
4. Select **Build → Build APK(s)** and then open `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to your phone and install it. The application itself requires no internet or special permissions.

The included `gradlew` script is a convenience launcher that uses a locally installed `gradle` command; there is no bundled Gradle wrapper JAR in this archive. Alternatively, install Gradle 8.9 and run `gradle :app:assembleDebug` directly. Android Studio may prompt to configure a Gradle installation.

## Refreshing atlas data

The currently bundled data is already generated in `app/src/main/assets/descraftrts_data.json`. To regenerate from your two PDFs, place both in `/mnt/data` at the paths configured in `tools/make_data.py`, then run `python tools/make_data.py`. That script needs the `pdftotext` utility. `python tools/check_data.py` runs dataset/matchup validations with no SDK.

## Project layout

```text
app/src/main/java/com/descraftrts/app/
  MainActivity.kt       Compose navigation, graph, filters, roster, search, upgrades
  Atlas.kt              JSON models, matchups, scoring and filtering
  Theme.kt              Dark navy / silver / blue / red color palette
app/src/main/assets/descraftrts_data.json   Bundled unit atlas
app/src/main/res/mipmap-*/ic_launcher.png   Approved option #6 at five densities
branding/DeScraft_icon_6.png              1024 × 1024 master icon

tools/make_data.py   PDF data extractor
tools/check_data.py  Data unit tests
```

## Cloud CI option

The `.github/workflows/android-apk.yml` file defines an Android SDK + Gradle build with an APK upload artifact. In a GitHub repository, run the **Build DeScraft Android APK** workflow to compile the project without installing Android Studio on your phone. This workflow is supplied but **has not been run in this environment**.
